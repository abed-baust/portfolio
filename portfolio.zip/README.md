# Md Abedur Rahman — Portfolio (Vue 3 + Vite)
Configured for GitHub Pages at `/portfolio/`.
## Run locally
npm install
npm run dev
## Build
npm run build
npm run preview