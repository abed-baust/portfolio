<template>
  <span class="badge">{{ label }}</span>
</template>
<script setup>
defineProps({ label: String })
</script>